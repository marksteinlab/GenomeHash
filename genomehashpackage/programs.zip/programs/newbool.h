//Copyright (c) in silico Labs, LLC, 2004

#ifndef NEWBOOL_INCLUDED
#define NEWBOOL_INCLUDED

#if defined(__cplusplus)
extern "C"
{
#endif

int newbool(int [][3], int,  char *boolstr);

#if defined(__cplusplus)
}
#endif 

#endif
